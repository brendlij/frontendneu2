import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import {
  fetchStudyProgram,
  saveStudyProgram,
  fetchLectures,
  fetchLecturers,
  addLectureToStudyProgram,
  addLecturerToStudyProgram,
} from "./StudyProgramService";

function EditStudyProgram() {
  const { id } = useParams();
  const navigate = useNavigate();

  // State für Studiengang-Daten
  const [name, setName] = useState("");
  const [shortName, setShortName] = useState("");

  // Optionslisten – getrennt für Vorlesungen und Dozenten
  const [lectures, setLectures] = useState([]);
  const [lecturersData, setLecturersData] = useState([]);

  // State für die ausgewählten IDs (als Strings, um Konsistenz in den <select>-Werten zu gewährleisten)
  const [selectedLectures, setSelectedLectures] = useState([]);
  const [selectedLecturers, setSelectedLecturers] = useState([]);

  // Bestehenden StudyProgram laden
  useEffect(() => {
    async function fetchData() {
      try {
        const studyProgram = await fetchStudyProgram(id);
        console.log("Fetched study program:", studyProgram);
        setName(studyProgram.name);
        setShortName(studyProgram.shortName);
        if (studyProgram.lectures && studyProgram.lectures.length > 0) {
          // Konvertiere IDs in Strings, da <select> Werte als Strings behandelt
          setSelectedLectures(
            studyProgram.lectures.map((lecture) => String(lecture.id))
          );
        }
        if (studyProgram.lecturers && studyProgram.lecturers.length > 0) {
          setSelectedLecturers(
            studyProgram.lecturers.map((lecturer) => String(lecturer.id))
          );
        }
      } catch (error) {
        console.error("Error fetching study program:", error.message);
      }
    }
    fetchData();
  }, [id]);

  // Alle verfügbaren Vorlesungen und Dozenten laden
  useEffect(() => {
    fetchLectures()
      .then((data) => {
        console.log("Fetched lectures:", data);
        setLectures(data);
      })
      .catch((error) =>
        console.error("Error fetching lectures:", error.message)
      );

    fetchLecturers()
      .then((data) => {
        console.log("Fetched lecturers:", data);
        setLecturersData(data);
      })
      .catch((error) =>
        console.error("Error fetching lecturers:", error.message)
      );
  }, []);

  async function handleSave(e) {
    e.preventDefault();

    // Erstelle das Update-Objekt – nur Name und ShortName werden gesendet,
    // um die bestehenden Collections im Backend beizubehalten (Merge-Strategie)
    const studyProgram = { id, name, shortName };

    console.log("Saving study program:", studyProgram);
    console.log("Selected lectures:", selectedLectures);
    console.log("Selected lecturers:", selectedLecturers);

    try {
      const updatedStudyProgram = await saveStudyProgram(studyProgram);
      console.log("Study program updated:", updatedStudyProgram);
      const spId = updatedStudyProgram.id;

      // Zugehörige Vorlesungen hinzufügen
      for (const lectureId of selectedLectures) {
        console.log(`Adding lecture ${lectureId} to study program ${spId}`);
        await addLectureToStudyProgram(spId, Number(lectureId));
      }

      for (const lecturerId of selectedLecturers) {
        console.log(`Adding lecturer ${lecturerId} to study program ${spId}`);
        await addLecturerToStudyProgram(spId, Number(lecturerId));
      }

      console.log("All associations saved. Navigating back to list...");
      navigate("/admin/studyprograms");
    } catch (error) {
      console.error("Error saving study program:", error);
      alert(
        "Failed to save study program. Please check the console for details."
      );
    }
  }

  return (
    <main className="content">
      <div id="content" className="px-4 mx-auto table-responsive">
        <div className="contentwrapper d-flex flex-column">
          <div className="bar d-flex justify-content-between mb-3 flex-row">
            <h2 id="contentTitle">Edit Study Program</h2>
          </div>
          <div className="d-flex text-muted text-start">
            <form className="w-100" id="form">
              <div className="mb-3">
                <label className="form-label">Name</label>
                <input
                  type="text"
                  className="form-control"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                />
              </div>
              <div className="mb-3">
                <label className="form-label">Short Name</label>
                <input
                  type="text"
                  className="form-control"
                  value={shortName}
                  onChange={(e) => setShortName(e.target.value)}
                  required
                />
              </div>
              <div className="mb-3">
                <label className="form-label">Lectures</label>
                <select
                  multiple
                  className="form-control"
                  value={selectedLectures}
                  onChange={(e) =>
                    setSelectedLectures(
                      Array.from(
                        e.target.selectedOptions,
                        (option) => option.value
                      )
                    )
                  }
                >
                  {lectures.map((lecture) => (
                    <option key={lecture.id} value={lecture.id}>
                      {lecture.lectureName}
                    </option>
                  ))}
                </select>
              </div>
              <div className="mb-3">
                <label className="form-label">Lecturers</label>
                <select
                  multiple
                  className="form-control"
                  value={selectedLecturers}
                  onChange={(e) =>
                    setSelectedLecturers(
                      Array.from(
                        e.target.selectedOptions,
                        (option) => option.value
                      )
                    )
                  }
                >
                  {lecturersData.map((lecturer) => (
                    <option key={lecturer.id} value={lecturer.id}>
                      {lecturer.firstName} {lecturer.lastName}
                    </option>
                  ))}
                </select>
              </div>
              <button
                onClick={handleSave}
                type="button"
                className="btn btn-primary"
                id="btnFormSubmit"
              >
                Save
              </button>
            </form>
          </div>
        </div>
      </div>
    </main>
  );
}

export default EditStudyProgram;
